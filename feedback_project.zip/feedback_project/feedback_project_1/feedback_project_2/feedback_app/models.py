# models.py

from django.db import models

class Feedback(models.Model):
    # Feedback model to store feedback information

    # Fields to store feedback data
    name = models.CharField(max_length=100, null=True, blank=True)  # Field for the name of the feedback provider
    address = models.CharField(max_length=100, default='Unknown')  # Field for the address (with a default value)
    program = models.CharField(max_length=100, null=True, blank=True)  # Field for the program of study
    country = models.CharField(max_length=100, null=True, blank=True)  # Field for the country of study
    duration = models.CharField(max_length=100, null=True, blank=True)  # Field for the duration of study
    feedback = models.TextField(null=True, blank=True)  # Field for the feedback message
    image = models.ImageField(upload_to='feedback_images/', null=True, blank=True)  # Field for uploading images

    # Meta class to provide additional information about the model
    class Meta:
        verbose_name_plural = "Feedback"  # Display name for the model in the admin interface
