from django.shortcuts import render, redirect
from .forms import FeedbackForm  # Importing the FeedbackForm from forms.py
from .models import Feedback  # Importing the Feedback model

def feedback_form(request):
    if request.method == 'POST':
        # If the request method is POST, process the form data
        form = FeedbackForm(request.POST, request.FILES)
        # Create a form instance with the POST data and files uploaded
        if form.is_valid():
            # If the form data is valid
            form.save()  # Save the form data to the database
            return redirect('feedback_info')  # Redirect to the feedback information page
    else:
        form = FeedbackForm()  # If the request method is not POST, create a blank form
    return render(request, 'feedbackform.html', {'form': form})
    # Render the feedback form template and pass the form instance to it

def feedback_info(request):
    # View function to display feedback information
    feedback_list = Feedback.objects.all()  # Retrieve all feedback entries from the database
    return render(request, 'feedbackinfo.html', {'feedback_list': feedback_list})
    # Render the feedback information template and pass the feedback list to it
