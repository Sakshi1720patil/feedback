from django.urls import path
from .views import feedback_form, feedback_info  # Importing view functions from views.py

urlpatterns = [
    # URL pattern for the feedback form view
    path('', feedback_form, name='feedback_form'),  # Empty path ('') for the feedback form
    # and associate it with the feedback_form view function. Assigning the name 'feedback_form'.
    
    # URL pattern for the feedback information view
    path('info/', feedback_info, name='feedback_info'),  # Path 'info/' for the feedback information page
    # and associate it with the feedback_info view function. Assigning the name 'feedback_info'.
]
